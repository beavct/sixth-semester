package conversores;

public abstract class Conversor {
    public abstract Double converter(Double temperatura);
    public abstract Conversor clone();
}
