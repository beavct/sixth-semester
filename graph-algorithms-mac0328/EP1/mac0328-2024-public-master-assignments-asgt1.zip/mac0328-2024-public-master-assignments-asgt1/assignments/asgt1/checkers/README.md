To compile run g++ checker-?.cpp, with ? being 0, 1 or 2.
This will generate an executable file called a.out.

To run one of the checkers a.out should be in a folder with all test
cases inputs, solutions and your code outputs, for a specific debug
level.

If you have any suggestions or find a bug, please report to:
thilio@ime.usp.br.

The checkers were done to help the students verify their answers
for assignment 1. These codes should NOT be used as a reference
for good code practices or what we are expecting from the assignments
submissions. We did not follow any code standard and the only purpose of
the checkers is to verify the answers correctly.

