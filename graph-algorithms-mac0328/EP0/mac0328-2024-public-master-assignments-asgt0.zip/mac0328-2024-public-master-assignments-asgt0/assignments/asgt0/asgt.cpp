/* This is the main file that the students must work on to submit; the
 * other one is arb.h
 */

#include "asgt.h"

Arb read_arb(std::istream& in)
{
  Arb arb(0);
  return arb;
}

HeadStart preprocess (Arb &arb, const Vertex& root)
{
  return HeadStart(42);
}

bool is_ancestor (const Vertex& u, const Vertex& v, const HeadStart& data)
{
  return false;
}
