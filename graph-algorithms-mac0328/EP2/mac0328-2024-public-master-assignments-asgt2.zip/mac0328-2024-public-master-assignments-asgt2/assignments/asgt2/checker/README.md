To compile run g++ checker-0.cpp.
This will generate an executable file called a.out.

To run the checker a.out should be in a folder with all test
cases inputs, solutions and your code outputs, for debug level 0.

If you have any suggestions or find a bug, please report to:
thilio@ime.usp.br.

The checker was done to help the students verify their answers
for assignment 2. This code should NOT be used as a reference
for good code practices or what we are expecting from the assignments
submissions. We did not follow any code standard and the only purpose of
the checker is to verify the answers correctly.
